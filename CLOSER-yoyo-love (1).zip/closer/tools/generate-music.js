/* Run with: node tools/generate-music.js
   Creates a gentle, original, loop-friendly piano-like ambient WAV file. */
const fs = require('fs');
const path = require('path');
const sampleRate = 22050;
const seconds = 48;
const samples = sampleRate * seconds;
const pcm = Buffer.alloc(samples * 2);
const chords = [
  [261.63,329.63,392.00,493.88], [220.00,261.63,329.63,392.00],
  [174.61,220.00,261.63,349.23], [196.00,246.94,293.66,392.00]
];
function envelope(t, duration) { const attack=Math.min(1,t/.035); const release=Math.min(1,(duration-t)/.65); return Math.max(0,Math.min(attack,release))*Math.exp(-Math.max(0,t-1.5)*.65); }
for (let i=0;i<samples;i++) {
  const t=i/sampleRate; const bar=Math.floor(t/6)%chords.length; const local=t%6;
  let value=0;
  chords[bar].forEach((f,n)=>{
    const phase=(t*f)%1;
    const fundamental=Math.sin(2*Math.PI*f*t);
    const harmonic=.22*Math.sin(4*Math.PI*f*t)+.08*Math.sin(6*Math.PI*f*t);
    const slowPulse=.82+.18*Math.sin(2*Math.PI*(.12+n*.018)*t);
    value+=(fundamental+harmonic)*envelope(local,5.9)*slowPulse*(n===0?.10:.052);
  });
  const melody=[chords[bar][2]*2,chords[bar][1]*2,chords[bar][3]*2,chords[bar][2]*2];
  const noteIndex=Math.floor(local/1.5); const noteTime=local%1.5; const mf=melody[noteIndex];
  value+=Math.sin(2*Math.PI*mf*t)*envelope(noteTime,1.42)*.025;
  const fade=Math.min(1,t/2,(seconds-t)/2); value*=Math.max(0,fade);
  const dither=(Math.random()-.5)*.00008; const sample=Math.max(-1,Math.min(1,value+dither)); pcm.writeInt16LE(Math.round(sample*32767),i*2);
}
const header=Buffer.alloc(44); header.write('RIFF',0);header.writeUInt32LE(36+pcm.length,4);header.write('WAVE',8);header.write('fmt ',12);header.writeUInt32LE(16,16);header.writeUInt16LE(1,20);header.writeUInt16LE(1,22);header.writeUInt32LE(sampleRate,24);header.writeUInt32LE(sampleRate*2,28);header.writeUInt16LE(2,32);header.writeUInt16LE(16,34);header.write('data',36);header.writeUInt32LE(pcm.length,40);
const output=path.join(__dirname,'..','assets','music','closer-ambient.wav');fs.writeFileSync(output,Buffer.concat([header,pcm]));console.log(`Created ${output} (${(fs.statSync(output).size/1024/1024).toFixed(2)} MB)`);
