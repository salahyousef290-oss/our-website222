# CLOSER — A thousand questions. A million little moments.

A static, mobile-first couples conversation game built with HTML, CSS and vanilla JavaScript. No server, account, framework or paid API is required.

## What's included

- 20 question categories with 60 prompts each (1,200 distinct entries).
- Random, next, previous, shuffle and reset session controls.
- Favorites saved in `localStorage`.
- Search, category filtering and a daily question.
- Deep Talk, Date Night, Random Challenge, Memory Lane, Future Together and Quick Fire modes.
- Light/dark themes and a quiet original local music track.
- Responsive layouts for phones, tablets and desktop browsers.

## Run locally

1. Open the `closer` folder in VS Code.
2. Open `index.html` in a browser. For the most reliable local experience, use VS Code's Live Server extension, or run `python -m http.server 8000` from this folder and visit `http://localhost:8000`.
3. Press **Start your journey**. Music never starts until you choose Play.

The site uses relative paths, so it also works from a GitHub Pages project URL.

## Music generation

The original 48-second ambient track is already included at `assets/music/closer-ambient.wav`. To regenerate it, install Node.js if needed, open a terminal in the project folder and run:

```bash
node tools/generate-music.js
```

This creates the WAV locally. The music player uses the local file and does not autoplay.

## Publish with GitHub Pages

1. Create a new GitHub repository named `closer` (or any name you like).
2. Upload the contents of this folder, keeping the folder structure intact. `index.html` must be at the repository root.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. Wait for the deployment to finish. GitHub will show the public URL in the Pages section, usually `https://YOUR-USERNAME.github.io/closer/`.

## Update later

Edit the relevant HTML, CSS or JS file in VS Code, save it, then commit and push/upload the changed files to the same repository. GitHub Pages republishes automatically after the update.

## Privacy and storage

Favorites, theme, music volume and lightweight session state stay in this browser's `localStorage`. Clearing site data in the browser clears those preferences. No information is sent to a server.
