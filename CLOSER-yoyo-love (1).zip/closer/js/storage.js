(() => {
  const KEY = 'closer-v1';
  const defaults = { favorites: [], theme: 'light', music: { enabled: false, volume: 0.18 }, session: null };
  let data;
  function load() {
    try { data = { ...defaults, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; }
    catch { data = JSON.parse(JSON.stringify(defaults)); }
    if (!Array.isArray(data.favorites)) data.favorites = [];
    if (!data.music) data.music = { ...defaults.music };
    return data;
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (error) { console.warn('CLOSER could not save preferences:', error); } }
  load();
  window.CloserStorage = {
    get: () => data,
    isFavorite: id => data.favorites.includes(id),
    toggleFavorite(id) { const i = data.favorites.indexOf(id); if (i >= 0) data.favorites.splice(i, 1); else data.favorites.push(id); save(); return i < 0; },
    clearFavorites() { data.favorites = []; save(); },
    setTheme(theme) { data.theme = theme; save(); },
    setMusic(patch) { data.music = { ...data.music, ...patch }; save(); },
    setSession(session) { data.session = session; save(); },
    clearSession() { data.session = null; save(); },
    save
  };
})();
